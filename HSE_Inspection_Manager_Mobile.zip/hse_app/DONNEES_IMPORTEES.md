# Données importées (Week 39)

| Feuille | Unité | Type | Lignes |
|---|---|---|---|
| 107D - Extincteurs | 107D | Extincteur | 137 |
| 107D - RIA | 107D | RIA | 24 |
| 107D - Douches de Sécurité | 107D | Douche de sécurité | 16 |
| Douchette de sécurité 107E | 107E | Douche de sécurité | 15 |
| 107E Extincteurs | 107E | Extincteur | 157 |
| 107E RIA (2) | 107E | RIA | 25 |
| 107F-Extincteurs | 107F | Extincteur | 150 |
| 107F-RIA | 107F | RIA | 25 |
| 107F-Douchette de sécurité | 107F | Douche de sécurité | 16 |
| RIA OSBL | OSBL | RIA | 54 |
| Extincteurs OSBL | OSBL | Extincteur | 105 |
| OSBL - Douches de Sécurité | OSBL | Douche de sécurité | 37 |
| **Total** | | | **761** (621 C · 135 NC · 5 P) |

Lignes ignorées: uniquement les lignes de totaux/synthèse en bas de feuille (17 lignes), aucune ligne d'inspection.
