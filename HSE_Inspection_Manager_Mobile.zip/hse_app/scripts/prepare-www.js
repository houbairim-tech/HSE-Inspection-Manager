// Copie frontend/ -> www/ et les librairies d'export (exceljs, jspdf) depuis node_modules
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const www = path.join(root, 'www');
fs.rmSync(www, { recursive: true, force: true });
fs.cpSync(path.join(root, 'frontend'), www, { recursive: true });
fs.mkdirSync(path.join(www, 'lib'), { recursive: true });
const libs = [
  ['node_modules/exceljs/dist/exceljs.min.js', 'lib/exceljs.min.js'],
  ['node_modules/jspdf/dist/jspdf.umd.min.js', 'lib/jspdf.umd.min.js']
];
for (const [from, to] of libs) {
  const src = path.join(root, from);
  if (!fs.existsSync(src)) { console.error('Introuvable: ' + from + ' (lancez "npm install" d\'abord)'); process.exit(1); }
  fs.copyFileSync(src, path.join(www, to));
}
console.log('www/ prêt');
