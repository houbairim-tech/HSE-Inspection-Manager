// À lancer après "npx cap add android": permissions caméra + icônes de l'application
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const res = path.join(root, 'android/app/src/main/res');
const manifest = path.join(root, 'android/app/src/main/AndroidManifest.xml');

let m = fs.readFileSync(manifest, 'utf8');
if (!m.includes('android.permission.CAMERA')) {
  m = m.replace(/(<uses-permission android:name="android.permission.INTERNET"\s*\/>)/,
    '$1\n    <uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />');
  fs.writeFileSync(manifest, m);
}

// Icônes: on supprime l'icône adaptative par défaut (Capacitor) et on pose la nôtre
fs.rmSync(path.join(res, 'mipmap-anydpi-v26'), { recursive: true, force: true });
const srcRes = path.join(root, 'android-res');
for (const d of fs.readdirSync(srcRes)) {
  const dest = path.join(res, d);
  fs.mkdirSync(dest, { recursive: true });
  for (const f of fs.readdirSync(path.join(srcRes, d))) fs.copyFileSync(path.join(srcRes, d, f), path.join(dest, f));
}
console.log('Android patché (caméra + icônes)');
