# HSE Inspection Manager
Extincteurs · RIA · Douches de sécurité — OCP · JESA · MMSE (Semaine 39)

- `frontend/` : application web/mobile (HTML + JS, hors-ligne)
- `frontend/epc_items.json` + `frontend/photos/` : données importées du fichier Excel
- Pour l'APK : voir `APK_AR.md`
- Test navigateur : `cd frontend && python -m http.server 8080`
